$(document).ready(function()
{
	var date = 'Today is: ' +  new Date($.now());
	$('#date').html(date);
});